local d = require('nibui.NOM').dynamic

return {
    x = 0, y = 0,
    w = d'^'('w'), h = d'^'('h'),
    background = 1,
}
