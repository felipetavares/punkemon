function console(t)
    clr(16)
end
