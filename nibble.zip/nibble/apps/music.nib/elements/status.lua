local d = require('nibui.NOM').dynamic

return {
    x = d'left', y = d'-'(d'bottom', 12),
    w = d'^' 'w', h = 12,
    background = 6,
    text_align = 'left',
    padding_left = 2,
    content = '...', }
